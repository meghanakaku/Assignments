package com.cg.lib.pl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.lib.dto.Book;
import com.cg.lib.exception.BookException;
import com.cg.lib.service.BookService;
import com.cg.lib.service.BookServiceImpl;






public class MainClass {
	static Book book = new Book();
	static BookService service = new BookServiceImpl();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int choice = 0;
		try(Scanner sc = new Scanner(System.in))
		{
			System.out.println("Enter user ID");
			String UserId=sc.next();
			
			try {
				boolean Id=service.searchByUserId(UserId);
				if(Id) {
					
			do
			{	
				
					System.out.println("1-Add Book to userAccount");
					System.out.println("2-Remove Book from userAccount");
					System.out.println("3-Search By Book Id in library");
					System.out.println("4-SearchAll issued Books to users");
					System.out.println("5- Update Book record into userAccount ");
					//System.out.println("6- Book issue date");
					//System.out.println("7- Book return date");
					System.out.println("Enter your choice::");
					choice = sc.nextInt();
					switch(choice)
					{
						case 1 : 
							
							Book user = acceptBookDetails(); 
							System.out.println(user);
							user.setUserId(UserId);
							
						if(user!=null){	
						try
						{
							
							int id = service.addBook(user);
							System.out.println("record inserted and id = "+id);
							
						}
						catch(BookException e)
						{
							System.out.println(e.getMessage());
						}}
						break;
						case 2:System.out.println("Enter Book  id to remove from userAccount::");
						int id = sc.nextInt();
						try
						{
							Book user1 = service.removeBook(id);
							System.out.println("Book has been removed from account "+user1);
						}
						catch(BookException e)
						{
							System.out.println(e.getMessage());
						}
						break;
						
						case 3 : System.out.println("Enter id to search Book in library:");
						int bId = sc.nextInt();
						try
						{
							Book ref = service.getBookById(bId);
							System.out.println("Book Details:: "+ref);
						}
						catch(BookException e)
						{
							System.out.println(e.getMessage());
						}
						break;
						case 4:
						try
						{							
							ArrayList<Book>list = service.getAllBook();
						
							for(Book obj : list)
						{
							System.out.println(obj);
						}
						}
						catch(BookException e)
						{
							System.out.println(e.getMessage());
						}
						break;	
						
						case 5: System.out.println("Enter id of Book to update  record::");
						int bId1 = sc.nextInt();
						System.out.println("Enter new price amount of book:");
						String publisher = sc.toString();
						//System.out.println("Enter Return Date");
								/*
								 * SimpleDateFormat sdf = new SimpleDateFormat("d-MMM-yy"); String
								 * returnDate1=sc.next(); Date returnDate=sdf.parse(returnDate1);
								 */
						try{
							Book eObj = service.updateBook(bId1, publisher);
							System.out.println("records has been updated = "+eObj);
						}
						catch(BookException e)
						{
							System.out.println(e.getMessage());
						}
						break;
					}
						//case 6: System.out.println("Enter Book issue Date::");
						
					
					System.out.println("do you want to continue 1-yes   0-No");
					choice = sc.nextInt();
				}while(choice!=0);
			}
			else {
					System.out.println("please enter proper userId/create userId ");
					System.out.println("create new  userLogin::");
					String createId=sc.next();
					try {
					String create=service.insertNewLogin(createId);
					if(create!=null)
					System.out.println("new user succesfully created");
					}catch (Exception e1) {
						// TODO: handle exception
						System.out.println("Please try again");
					}}
				}
				catch (Exception e) {
					/*System.out.println("please enter proper studentId/create studentId ");
					System.out.println("create new  studentLogin::");
					String createId=sc.next();
					try {
					String create=service.insertNewLogin(createId);
					if(create!=null)
					System.out.println("new student succesfully created");
					}catch (Exception e1) {
						// TODO: handle exception
						System.out.println("Please try again");
					}*/
					System.out.println(e.getMessage());
				}
			}catch (Exception e) {
				// TODO: handle exception
				System.out.println(e.getMessage());
			}

		
		
		}
						
					
		
					public static Book acceptBookDetails() throws ParseException
					{
						
						Scanner sc = new Scanner(System.in);
						while(true)
						{
							System.out.println("Enter Book name to add in StudentAccount:");
							String name = sc.next();
							if(!service.validateName(name))
							{
								continue;
							}
							else
							{
								while(true)
								{
									System.out.println("Enter Book author1 of book");
									String author = sc.next();
									
									if(!service.validateName(author))
									{
										continue;
									}
									
									
										System.out.println("Enter author2  of book");
											String author2 = sc.next();
											
										System.out.println("Enter publisher of book");
													String publisher = sc.next();

										//System.out.println("Enter year of publication of book");
										//String yearofpublication = sc.next();
										
													book.setBook_name(name);
													book.setAuthor1(author);
													book.setAuthor2(author2);
													book.setPublisher(publisher);
													//lib.setYearofpublication(yearofpublication);
//													 System.out
//															.println(book);
													 break;
												}
											}
										
									
									return book;
									}
										}
	}
				

