package com.cg.lib.service;

import java.util.ArrayList;

import com.cg.lib.dto.Book;
import com.cg.lib.exception.BookException;


public interface BookService {
	int addBook(Book lib)throws BookException;
	Book removeBook(int libId)throws BookException;
	Book getBookById(int libId)throws BookException;
	ArrayList<Book>getAllBook()throws BookException;
	Book updateBook(int bId,String publisher)throws BookException;
	boolean searchByUserId(String UserId);
	//boolean validateSalary(int price);
	boolean validateName(String author1);
	boolean validateName(String name, String author);
	String insertNewLogin(String createId);
}


