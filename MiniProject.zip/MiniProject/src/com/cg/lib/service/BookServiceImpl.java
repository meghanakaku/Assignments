package com.cg.lib.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.lib.dao.BookDao;
import com.cg.lib.dao.BookDaoImpl;
import com.cg.lib.dto.Book;
import com.cg.lib.exception.BookException;



public class BookServiceImpl implements BookService {
	BookDao dao;
	
	public void setDao(BookDao dao)
	{
		this.dao = dao;
	}
	
	public BookServiceImpl()
	{
		dao = new BookDaoImpl();
	}

	@Override
	public int addBook(Book lib) throws BookException {
		// TODO Auto-generated method stub
		
		return dao.addBook(lib);
	}

	@Override
	public Book removeBook(int libId) throws BookException {
		// TODO Auto-generated method stub
		return dao.removeBook(libId);
	}

	@Override
	public Book getBookById(int libId) throws BookException {
		// TODO Auto-generated method stub
		return dao.getBookById(libId);
	}

	@Override
	public ArrayList<Book> getAllBook() throws BookException {
		// TODO Auto-generated method stub
		return dao.getAllBook();
	}

	@Override
	public Book updateBook(int bId, String publisher) throws BookException {
		// TODO Auto-generated method stub
		return dao.updateBook(bId, publisher);
	}

	@Override
	public boolean searchByUserId(String UserId) {
		// TODO Auto-generated method stub
		return dao.searchByUserId(UserId);
	}

	@Override
	public boolean validateName(String author1) {
		// TODO Auto-generated method stub
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,author1))
		{
			return true;
		}
		else
			return false;
	}
	
	@Override
	public boolean validateName(String name, String author) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String insertNewLogin(String createId) {
		// TODO Auto-generated method stub
		
		return dao.insertNewLogin(createId);
	}

}
