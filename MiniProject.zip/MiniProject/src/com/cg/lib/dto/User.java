package com.cg.lib.dto;

public class User {

	
	private String User_id;

	
	public User() {
		// TODO Auto-generated constructor stub
	}

	public String getUser_id() {
		return User_id;
	}

	public void setUser_id(String user_id) {
		User_id = user_id;
	}

	@Override
	public String toString() {
		return "User [User_id=" + User_id + "]";
	}

	public User(String user_id) {
		super();
		User_id = user_id;
	}
	
}
