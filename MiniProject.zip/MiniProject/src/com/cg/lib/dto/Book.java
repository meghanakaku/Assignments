package com.cg.lib.dto;

import java.sql.Date;

public class Book {

	
	private int book_id;
	private String book_name;
	private String author1;
	private String author2;
	private String publisher;
	private  String yearofpublication;
	private Date issueDate;
	private Date returnDate;
	private String UserId;
	
	public Book() {
		super();
	}

	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getAuthor1() {
		return author1;
	}
	public void setAuthor1(String author1) {
		this.author1 = author1;
	}
	public String getAuthor2() {
		return author2;
	}
	public void setAuthor2(String author2) {
		this.author2 = author2;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getYearofpublication() {
		return yearofpublication;
	}
	public void setYearofpublication(String yearofpublication) {
		this.yearofpublication = yearofpublication;
	}
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	public String getUserId() {
		return UserId;
	}
	public void setUserId(String userId) {
		UserId = userId;
	}

	public int getBook_id() {
		return book_id;
	}

	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}

	@Override
	public String toString() {
		return "Book [book_id=" + book_id + ", book_name=" + book_name
				+ ", author1=" + author1 + ", author2=" + author2
				+ ", publisher=" + publisher + ", yearofpublication="
				+ yearofpublication + ", issueDate=" + issueDate
				+ ", returnDate=" + returnDate + ", UserId=" + UserId + "]";
	}

	public Book(int book_id, String book_name, String author1, String author2,
			String publisher, String yearofpublication, Date issueDate,
			Date returnDate, String userId) {
		super();
		this.book_id = book_id;
		this.book_name = book_name;
		this.author1 = author1;
		this.author2 = author2;
		this.publisher = publisher;
		this.yearofpublication = yearofpublication;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
		UserId = userId;
	}

	
}
