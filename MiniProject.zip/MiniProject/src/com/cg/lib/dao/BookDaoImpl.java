package com.cg.lib.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Logger;

import com.cg.lib.dto.Book;
import com.cg.lib.exception.BookException;
import com.cg.lib.util.DBUtil;





public class BookDaoImpl implements BookDao{
	
	Connection con;
	Logger logger;
	
	public BookDaoImpl()
	{
		con = DBUtil.getConnect();
		//logger = MyLogger.getLogger();
	}

	
	@Override
	public String insertNewLogin(String UserId) {
		// TODO Auto-generated method stub
		
		String query = "INSERT INTO Users VALUES(?)";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(query);
			pstmt.setString(1, UserId);
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				
				logger.info("Inserted successfully and Id is = "+UserId);
			}
			else
				throw new BookException("unable to insert"+UserId);
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
			System.out.println("Please try again");
		}
		return UserId;
	}
	
	
	
	
		
	@Override
	public int addBook(Book lib) throws BookException {
		// TODO Auto-generated method stub
		
		logger.info("In Add Book");
		//logger.info("Input is "+student);
		int id =0;
		String qry = "INSERT INTO BooksInventory VALUES(bId_seq.NEXTVAL,?,?,?,?,?,sysdate,sysdate+14,?)";

		String name = lib.getBook_name();
		String author1 = lib.getAuthor1();
		String author2 = lib.getAuthor2();
		String publisher=lib.getPublisher();
		String yearofpublication = lib.getYearofpublication();
		//Date returnDate=student.getReturnDate();
		String userId=lib.getUserId();
		
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setString(1, name);
			pstmt.setString(2,author1);
			pstmt.setString(3, author2);
			pstmt.setString(4, publisher);
			pstmt.setString(5, yearofpublication);
		//	pstmt.setDate(5, returnDate);
			pstmt.setString(5, userId);
		
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				id = getBookId();
				logger.info("Inserted successfully and Id is = "+id);
			}
			else
				throw new BookException("unable to insert"+lib);
			
		}
		catch(SQLException e)
		{
			//logger.error("Error in insert = "+e.getMessage());
			throw new BookException(e.getMessage());
		}
		return id;
		
	}

	@Override
	public Book removeBook(int bId) throws BookException {
		// TODO Auto-generated method stub
		Book lib = null;
		String qry = "DELETE FROM BooksInventory WHERE bId=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, bId);
			lib = getBookById(bId);
			int row = pstmt.executeUpdate();
			if(lib==null)
			{
				throw new BookException("book-id "+bId+"not found");
			}
			else if(row > 0)
			{
				System.out.println("Deleted book from account  with Id "+bId);
				
			}
			
		}
		catch(SQLException e)
		{
			throw new BookException(e.getMessage());
		}
		return lib;
	}
		

	@Override
	public Book getBookById(int bId) throws BookException {
		// TODO Auto-generated method stub
		Book lib = null;
		String qry = "SELECT * FROM BooksInventory WHERE bId=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, bId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{

				int id = rs.getInt(1);

				String name = rs.getString(2);
				String author1 = rs.getString(3);
				String author2 = rs.getString(4);
				String publisher=rs.getString(5);
				String yearofpublication = rs.getString(6);
				//Date returnDate=student.getReturnDate();
				Date issueDate=rs.getDate(7);
				Date returnDate=rs.getDate(8);
				String userId=rs.getString(9);
				
				
			
				
			
				lib = new Book(id,name,author1,author2,publisher,yearofpublication,issueDate,returnDate,userId);
			}
			else
				throw new BookException("Book-id "+bId+"not found");
		}
		catch(SQLException e)
		{
			throw new BookException(e.getMessage());
		}
		return lib;
	}
	

	@Override
	public ArrayList<Book> getAllBook() throws BookException {
		// TODO Auto-generated method stub
		ArrayList<Book>list = new ArrayList<Book>();
		String qry = "SELECT * FROM BooksInventory";
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int id = rs.getInt(1);
			String name = rs.getString(2);
			String author1 = rs.getString(3);
			String author2 = rs.getString(4);
			String publisher = rs.getString(5);
			String yearofpublication=rs.getString(6);
			Date issueDate=rs.getDate(7);
			Date returnDate=rs.getDate(8);
			String UserId=rs.getString(9);
				
				Book lib = new Book(id,name,author1,author2,publisher,yearofpublication,issueDate,returnDate,UserId);
				list.add(lib);
			}
		}
		catch(SQLException e)
		{
			throw new BookException(e.getMessage());
		}
		return list;
	}
		
		
	
	@Override
	public Book updateBook(int bId, String publisher) throws BookException {
		// TODO Auto-generated method stub
		Book lib = getBookById(bId);
		Date returnDate1=null;
		if(lib==null)
			throw new BookException("Book-id "+bId+"Not found");
		else
		{
			//String qry = "UPDATE BookJEE SET bPrice=?, returnDate=? WHERE bId=?";
			String qry = "UPDATE BooksInventory SET publisher=? WHERE bId=?";
			try{
				PreparedStatement pstmt = con.prepareStatement(qry);
				
				pstmt.setString(1,publisher );
				pstmt.setInt(2, bId);
				//pstmt.setDate(3, (Date) returnDate);
				int row = pstmt.executeUpdate();
				if(row > 0)
				{
					System.out.println("updated successfully");
					lib = getBookById(bId);
				}      
			}
			catch(SQLException e)
			{
				throw new BookException(e.getMessage());
			}
			
		}
		return lib;
	}

	

	

	public int getBookId()throws BookException
	{
		logger.info("In getBookId");
		int id = 0;
		String qry = "SELECT book_id.CURRVAL FROM DUAL";
			try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id = rs.getInt(1);
				logger.info("Got Book With Id"+id);
			}
			}
			catch(SQLException e)
			{
				//logger.error("Error"+e.getMessage());
				throw new BookException(e.getMessage());
			}
			logger.info("Completed getBookId");
			return id;
		
	}


	@Override
	public boolean searchByUserId(String UserId) {
		// TODO Auto-generated method stub
		
		String qry="SELECT * From Users where UserId=?";
		try {
			//Statement stmt = con.createStatement();
			PreparedStatement pstm=con.prepareStatement(qry);
			pstm.setString(1, UserId);
			ResultSet rs1=pstm.executeQuery();
			//boolean rs1 = pstm.execute(qry) ;
			if(rs1.next())
			{
				return true;
				
			}
			/*
			 * else { logger.info("In Add Book"); logger.info("Input is "+ studentId);
			 * 
			 * String query = "INSERT INTO StudentDetails VALUES(?)"; try {
			 * PreparedStatement pstmt = con.prepareStatement(query); pstmt.setString(1,
			 * studentId); int row = pstmt.executeUpdate(); if(row > 0) {
			 * 
			 * logger.info("Inserted successfully and Id is = "+studentId); } else throw new
			 * BookException("unable to insert"+studentId); } catch (Exception e) { // TODO:
			 * handle exception System.out.println("Please try again"); }
			 * 
			 * }
			 */
		}catch (SQLException e) {
			// TODO: handle exception
			System.out.println("Please check with correct  details");
		}
		return false;
	}

		
	
}
