package com.cg.lib.dao;

import java.util.ArrayList;

import com.cg.lib.dto.Book;
import com.cg.lib.exception.BookException;



public interface BookDao {

	
	int addBook(Book lib)throws BookException;
	Book removeBook(int libId)throws BookException;
	Book getBookById(int libId)throws BookException;
	ArrayList<Book>getAllBook()throws BookException;
	Book updateBook(int bId,String publisher)throws BookException;
	boolean searchByUserId(String UserId);
	String insertNewLogin(String createId);
}
